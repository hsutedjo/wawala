﻿namespace Take_Home_14
{
    partial class Form_InsertMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Insert = new System.Windows.Forms.Button();
            this.dgv_Match = new System.Windows.Forms.DataGridView();
            this.btn_Add = new System.Windows.Forms.Button();
            this.lbl_AddPlayer = new System.Windows.Forms.Label();
            this.cbox_AddPlayer = new System.Windows.Forms.ComboBox();
            this.lbl_AddType = new System.Windows.Forms.Label();
            this.cbox_AddType = new System.Windows.Forms.ComboBox();
            this.lbl_AddTeam = new System.Windows.Forms.Label();
            this.cbox_AddTeam = new System.Windows.Forms.ComboBox();
            this.txtbox_AddMinute = new System.Windows.Forms.TextBox();
            this.lbl_AddMinute = new System.Windows.Forms.Label();
            this.lbl_MatchDate = new System.Windows.Forms.Label();
            this.lbl_TeamAway = new System.Windows.Forms.Label();
            this.cbox_TeamAway = new System.Windows.Forms.ComboBox();
            this.lbl_TeamHome = new System.Windows.Forms.Label();
            this.dtp_MatchDate = new System.Windows.Forms.DateTimePicker();
            this.cbox_TeamHome = new System.Windows.Forms.ComboBox();
            this.txtbox_MatchID = new System.Windows.Forms.TextBox();
            this.lbl_MatchID = new System.Windows.Forms.Label();
            this.btn_Delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Match)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(312, 356);
            this.btn_Insert.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(141, 26);
            this.btn_Insert.TabIndex = 39;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // dgv_Match
            // 
            this.dgv_Match.AllowUserToAddRows = false;
            this.dgv_Match.AllowUserToDeleteRows = false;
            this.dgv_Match.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Match.Location = new System.Drawing.Point(36, 141);
            this.dgv_Match.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_Match.Name = "dgv_Match";
            this.dgv_Match.ReadOnly = true;
            this.dgv_Match.RowHeadersWidth = 82;
            this.dgv_Match.RowTemplate.Height = 33;
            this.dgv_Match.Size = new System.Drawing.Size(358, 196);
            this.dgv_Match.TabIndex = 38;
            this.dgv_Match.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Match_CellDoubleClick);
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(440, 277);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(62, 19);
            this.btn_Add.TabIndex = 37;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // lbl_AddPlayer
            // 
            this.lbl_AddPlayer.AutoSize = true;
            this.lbl_AddPlayer.Location = new System.Drawing.Point(415, 215);
            this.lbl_AddPlayer.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_AddPlayer.Name = "lbl_AddPlayer";
            this.lbl_AddPlayer.Size = new System.Drawing.Size(36, 13);
            this.lbl_AddPlayer.TabIndex = 36;
            this.lbl_AddPlayer.Text = "Player";
            // 
            // cbox_AddPlayer
            // 
            this.cbox_AddPlayer.FormattingEnabled = true;
            this.cbox_AddPlayer.Location = new System.Drawing.Point(482, 214);
            this.cbox_AddPlayer.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_AddPlayer.Name = "cbox_AddPlayer";
            this.cbox_AddPlayer.Size = new System.Drawing.Size(102, 21);
            this.cbox_AddPlayer.TabIndex = 35;
            // 
            // lbl_AddType
            // 
            this.lbl_AddType.AutoSize = true;
            this.lbl_AddType.Location = new System.Drawing.Point(414, 244);
            this.lbl_AddType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_AddType.Name = "lbl_AddType";
            this.lbl_AddType.Size = new System.Drawing.Size(31, 13);
            this.lbl_AddType.TabIndex = 34;
            this.lbl_AddType.Text = "Type";
            // 
            // cbox_AddType
            // 
            this.cbox_AddType.FormattingEnabled = true;
            this.cbox_AddType.Location = new System.Drawing.Point(482, 242);
            this.cbox_AddType.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_AddType.Name = "cbox_AddType";
            this.cbox_AddType.Size = new System.Drawing.Size(102, 21);
            this.cbox_AddType.TabIndex = 33;
            // 
            // lbl_AddTeam
            // 
            this.lbl_AddTeam.AutoSize = true;
            this.lbl_AddTeam.Location = new System.Drawing.Point(414, 187);
            this.lbl_AddTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_AddTeam.Name = "lbl_AddTeam";
            this.lbl_AddTeam.Size = new System.Drawing.Size(34, 13);
            this.lbl_AddTeam.TabIndex = 32;
            this.lbl_AddTeam.Text = "Team";
            // 
            // cbox_AddTeam
            // 
            this.cbox_AddTeam.FormattingEnabled = true;
            this.cbox_AddTeam.Location = new System.Drawing.Point(482, 186);
            this.cbox_AddTeam.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_AddTeam.Name = "cbox_AddTeam";
            this.cbox_AddTeam.Size = new System.Drawing.Size(102, 21);
            this.cbox_AddTeam.TabIndex = 31;
            this.cbox_AddTeam.SelectionChangeCommitted += new System.EventHandler(this.cbox_AddTeam_SelectionChangeCommitted);
            // 
            // txtbox_AddMinute
            // 
            this.txtbox_AddMinute.Location = new System.Drawing.Point(482, 159);
            this.txtbox_AddMinute.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_AddMinute.Name = "txtbox_AddMinute";
            this.txtbox_AddMinute.Size = new System.Drawing.Size(102, 20);
            this.txtbox_AddMinute.TabIndex = 30;
            // 
            // lbl_AddMinute
            // 
            this.lbl_AddMinute.AutoSize = true;
            this.lbl_AddMinute.Location = new System.Drawing.Point(414, 161);
            this.lbl_AddMinute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_AddMinute.Name = "lbl_AddMinute";
            this.lbl_AddMinute.Size = new System.Drawing.Size(39, 13);
            this.lbl_AddMinute.TabIndex = 29;
            this.lbl_AddMinute.Text = "Minute";
            // 
            // lbl_MatchDate
            // 
            this.lbl_MatchDate.AutoSize = true;
            this.lbl_MatchDate.Location = new System.Drawing.Point(331, 37);
            this.lbl_MatchDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_MatchDate.Name = "lbl_MatchDate";
            this.lbl_MatchDate.Size = new System.Drawing.Size(63, 13);
            this.lbl_MatchDate.TabIndex = 28;
            this.lbl_MatchDate.Text = "Match Date";
            // 
            // lbl_TeamAway
            // 
            this.lbl_TeamAway.AutoSize = true;
            this.lbl_TeamAway.Location = new System.Drawing.Point(331, 73);
            this.lbl_TeamAway.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TeamAway.Name = "lbl_TeamAway";
            this.lbl_TeamAway.Size = new System.Drawing.Size(63, 13);
            this.lbl_TeamAway.TabIndex = 27;
            this.lbl_TeamAway.Text = "Team Away";
            // 
            // cbox_TeamAway
            // 
            this.cbox_TeamAway.FormattingEnabled = true;
            this.cbox_TeamAway.Location = new System.Drawing.Point(398, 71);
            this.cbox_TeamAway.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_TeamAway.Name = "cbox_TeamAway";
            this.cbox_TeamAway.Size = new System.Drawing.Size(102, 21);
            this.cbox_TeamAway.TabIndex = 26;
            this.cbox_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cbox_TeamAway_SelectedIndexChanged);
            // 
            // lbl_TeamHome
            // 
            this.lbl_TeamHome.AutoSize = true;
            this.lbl_TeamHome.Location = new System.Drawing.Point(34, 71);
            this.lbl_TeamHome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TeamHome.Name = "lbl_TeamHome";
            this.lbl_TeamHome.Size = new System.Drawing.Size(65, 13);
            this.lbl_TeamHome.TabIndex = 25;
            this.lbl_TeamHome.Text = "Team Home";
            // 
            // dtp_MatchDate
            // 
            this.dtp_MatchDate.Location = new System.Drawing.Point(398, 36);
            this.dtp_MatchDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_MatchDate.Name = "dtp_MatchDate";
            this.dtp_MatchDate.Size = new System.Drawing.Size(186, 20);
            this.dtp_MatchDate.TabIndex = 24;
            this.dtp_MatchDate.ValueChanged += new System.EventHandler(this.dtp_MatchDate_ValueChanged);
            // 
            // cbox_TeamHome
            // 
            this.cbox_TeamHome.FormattingEnabled = true;
            this.cbox_TeamHome.Location = new System.Drawing.Point(100, 70);
            this.cbox_TeamHome.Margin = new System.Windows.Forms.Padding(2);
            this.cbox_TeamHome.Name = "cbox_TeamHome";
            this.cbox_TeamHome.Size = new System.Drawing.Size(102, 21);
            this.cbox_TeamHome.TabIndex = 23;
            this.cbox_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cbox_TeamHome_SelectedIndexChanged);
            // 
            // txtbox_MatchID
            // 
            this.txtbox_MatchID.Enabled = false;
            this.txtbox_MatchID.Location = new System.Drawing.Point(100, 34);
            this.txtbox_MatchID.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_MatchID.Name = "txtbox_MatchID";
            this.txtbox_MatchID.Size = new System.Drawing.Size(102, 20);
            this.txtbox_MatchID.TabIndex = 22;
            // 
            // lbl_MatchID
            // 
            this.lbl_MatchID.AutoSize = true;
            this.lbl_MatchID.Location = new System.Drawing.Point(34, 36);
            this.lbl_MatchID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_MatchID.Name = "lbl_MatchID";
            this.lbl_MatchID.Size = new System.Drawing.Size(51, 13);
            this.lbl_MatchID.TabIndex = 21;
            this.lbl_MatchID.Text = "Match ID";
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(519, 277);
            this.btn_Delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(62, 19);
            this.btn_Delete.TabIndex = 20;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // Form_InsertMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 404);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.dgv_Match);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.lbl_AddPlayer);
            this.Controls.Add(this.cbox_AddPlayer);
            this.Controls.Add(this.lbl_AddType);
            this.Controls.Add(this.cbox_AddType);
            this.Controls.Add(this.lbl_AddTeam);
            this.Controls.Add(this.cbox_AddTeam);
            this.Controls.Add(this.txtbox_AddMinute);
            this.Controls.Add(this.lbl_AddMinute);
            this.Controls.Add(this.lbl_MatchDate);
            this.Controls.Add(this.lbl_TeamAway);
            this.Controls.Add(this.cbox_TeamAway);
            this.Controls.Add(this.lbl_TeamHome);
            this.Controls.Add(this.dtp_MatchDate);
            this.Controls.Add(this.cbox_TeamHome);
            this.Controls.Add(this.txtbox_MatchID);
            this.Controls.Add(this.lbl_MatchID);
            this.Controls.Add(this.btn_Delete);
            this.Name = "Form_InsertMatch";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form_InsertMatch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Insert;
        private System.Windows.Forms.DataGridView dgv_Match;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Label lbl_AddPlayer;
        private System.Windows.Forms.ComboBox cbox_AddPlayer;
        private System.Windows.Forms.Label lbl_AddType;
        private System.Windows.Forms.ComboBox cbox_AddType;
        private System.Windows.Forms.Label lbl_AddTeam;
        private System.Windows.Forms.ComboBox cbox_AddTeam;
        private System.Windows.Forms.TextBox txtbox_AddMinute;
        private System.Windows.Forms.Label lbl_AddMinute;
        private System.Windows.Forms.Label lbl_MatchDate;
        private System.Windows.Forms.Label lbl_TeamAway;
        private System.Windows.Forms.ComboBox cbox_TeamAway;
        private System.Windows.Forms.Label lbl_TeamHome;
        private System.Windows.Forms.DateTimePicker dtp_MatchDate;
        private System.Windows.Forms.ComboBox cbox_TeamHome;
        private System.Windows.Forms.TextBox txtbox_MatchID;
        private System.Windows.Forms.Label lbl_MatchID;
        private System.Windows.Forms.Button btn_Delete;
    }
}

