﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Take_Home_14
{
    public partial class Form_InsertMatch : Form
    {
        public Form_InsertMatch()
        {
            InitializeComponent();
        }
        MySqlConnection SqlConnect;
        MySqlCommand SqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        string query;
        int index = 0;
        DataTable dtMatchRecord = new DataTable();
        DataTable dtHome = new DataTable();
        DataTable dtAway = new DataTable();
        DataTable dtSelectedTeam = new DataTable();
        DataTable dtAddRecord = new DataTable();
        DataTable dtPlayer = new DataTable();
        List<string> ltype = new List<string> {"GO", "GP", "GW", "CR", "CY", "PM"};
        List<string> playerid = new List<string>();
        bool fin = false;

        private void Form_InsertMatch_Load(object sender, EventArgs e)
        {
            SqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Heidysutedjo05;database=premier_league");
            SqlConnect.Open();
            query = "SELECT team_id, team_name FROM team;";
            SqlCommand = new MySqlCommand(query, SqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dtHome);
            SqlDataAdapter.Fill(dtAway);
            cbox_TeamHome.DataSource = dtHome;
            cbox_TeamHome.DisplayMember = "team_name";
            cbox_TeamHome.ValueMember = "team_id";
            cbox_TeamAway.DataSource = dtAway;
            cbox_TeamAway.DisplayMember = "team_name";
            cbox_TeamAway.ValueMember = "team_id";
            query = "SELECT player_id, player_name, team_id FROM player;";
            SqlCommand = new MySqlCommand(query, SqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dtPlayer);
            foreach (string type in ltype)
            {
                cbox_AddType.Items.Add(type);
            }
            dtSelectedTeam.Columns.Add("team_id");
            dtSelectedTeam.Columns.Add("team_name");
            dtAddRecord.Columns.Add("Minute");
            dtAddRecord.Columns.Add("Team");
            dtAddRecord.Columns.Add("Player");
            dtAddRecord.Columns.Add("Type");
            dgv_Match.DataSource = dtAddRecord;
            cbox_TeamHome.SelectedItem = null;
            cbox_TeamAway.SelectedItem = null;
            fin = true;
        }
        private void cbox_AddTeam_SelectionChangeCommitted(object sender, EventArgs e)
        {
            query = $"SELECT player_id, player_name FROM player WHERE team_id = '{cbox_AddTeam.SelectedValue}';";
            SqlCommand = new MySqlCommand(query, SqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtPlayer.Clear();
            SqlDataAdapter.Fill(dtPlayer);
            cbox_AddPlayer.DataSource = dtPlayer;
            cbox_AddPlayer.ValueMember = "player_id";
            cbox_AddPlayer.DisplayMember = "player_name";
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (txtbox_MatchID.Text != "" && txtbox_AddMinute.Text != "" && cbox_AddTeam.SelectedItem != null && cbox_AddPlayer.SelectedItem != null && cbox_AddType.SelectedItem != null)
            {
                dtAddRecord.Rows.Add(txtbox_AddMinute.Text, cbox_AddTeam.Text, cbox_AddPlayer.Text, cbox_AddType.Text);
                playerid.Add(cbox_AddPlayer.SelectedValue.ToString());
                txtbox_AddMinute.Clear();
                cbox_AddTeam.SelectedItem = null;
                cbox_AddPlayer.SelectedItem = null;
                cbox_AddType.SelectedItem = null;
            }
            else
            {
                MessageBox.Show("Please Fill In All Fields");
            }
        }
        private void dgv_Match_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            index = dgv_Match.CurrentCell.RowIndex;
            cbox_AddTeam.Text = dtAddRecord.Rows[index][1].ToString();
            cbox_AddPlayer.Text = dtAddRecord.Rows[index][2].ToString();
            cbox_AddType.Text = dtAddRecord.Rows[index][3].ToString();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if(dtAddRecord.Rows.Count > 0)
            {
                if (cbox_AddTeam.Text == dtAddRecord.Rows[index][1].ToString() && cbox_AddTeam.SelectedItem != null && cbox_AddPlayer.SelectedItem != null && cbox_AddType.SelectedItem != null)
                {
                    dtAddRecord.Rows[index].Delete();
                    playerid.RemoveAt(index);
                }
                else
                {
                    MessageBox.Show("Please Select a Data From the DGV");
                }
            }
            else
            {
                MessageBox.Show("Please Put In Match Record First");
            }
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            int goalhome = 0;
            int goalaway = 0;
            if(dtAddRecord.Rows.Count > 0)
            {
                for(int i = 0; i < dtAddRecord.Rows.Count; i++)
                {
                    if (dtAddRecord.Rows[i][1].ToString() == dtSelectedTeam.Rows[0][1].ToString())
                    {
                        if (dtAddRecord.Rows[i][3].ToString() == "GO" || dtAddRecord.Rows[i][3].ToString() == "GP")
                        {
                            goalhome++;
                        }
                        else if(dtAddRecord.Rows[i][3].ToString() == "GW")
                        {
                            goalaway++;
                        }
                    }
                    else if (dtAddRecord.Rows[i][1].ToString() == dtSelectedTeam.Rows[1][1].ToString())
                    {
                        if (dtAddRecord.Rows[i][3].ToString() == "GO" || dtAddRecord.Rows[i][3].ToString() == "GP")
                        {
                            goalaway++;
                        }
                        else if (dtAddRecord.Rows[i][3].ToString() == "GW")
                        {
                            goalhome++;
                        }
                    }
                }
                query = $"INSERT INTO `match` VALUES ('{txtbox_MatchID.Text}', '{dtp_MatchDate.Value.ToString("yyyy-MM-dd")}', '{cbox_TeamHome.SelectedValue}', '{cbox_TeamAway.SelectedValue}', '{goalhome}', '{goalaway}', 'M002', '0');";
                SqlCommand = new MySqlCommand(query, SqlConnect);
                SqlCommand.ExecuteNonQuery();
                List<string> teamid = new List<string>();
                foreach (DataRow record in dtAddRecord.Rows)
                {
                    if (record[1].ToString() == cbox_TeamHome.Text)
                    {
                        teamid.Add(cbox_TeamHome.SelectedValue.ToString());
                    }
                    else if (record[1].ToString() == cbox_TeamAway.Text)
                    {
                        teamid.Add(cbox_TeamAway.SelectedValue.ToString());
                    }
                }
                for (int i = 0; i < dtAddRecord.Rows.Count; i++)
                {
                    query = $"INSERT INTO dmatch VALUES ('{txtbox_MatchID.Text}', '{dtAddRecord.Rows[i][0]}', '{teamid[i]}', '{playerid[i]}', '{dtAddRecord.Rows[i][3]}', '0');";
                    SqlCommand = new MySqlCommand(query, SqlConnect);
                    SqlCommand.ExecuteNonQuery();
                }
                dtAddRecord.Clear();
                txtbox_MatchID.Clear();
                playerid.Clear();
                cbox_TeamHome.SelectedItem = null;
                cbox_TeamAway.SelectedItem = null;
            }
            else
            {
                MessageBox.Show("Please Input Match Record");
            }
        }

        private void dtp_MatchDate_ValueChanged(object sender, EventArgs e)
        {
            query = $"SELECT match_id, match_date from `match`;";
            SqlCommand = new MySqlCommand(query, SqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtMatchRecord.Clear();
            SqlDataAdapter.Fill(dtMatchRecord);
            int count = 0;
            string year = dtp_MatchDate.Value.Year.ToString();
            var date = new DateTime(2016, 2, 16);
            foreach (DataRow record in dtMatchRecord.Rows)
            {
                if (record[0].ToString().Substring(0,4) == year)
                {
                    count++;
                }
                if (Convert.ToDateTime(record[1]) > date)
                {
                    date = Convert.ToDateTime(record[1]);
                }
            }
            if(Convert.ToDateTime(dtp_MatchDate.Text) < date)
            {
                MessageBox.Show("Cannot Pick Date Under Last Match");
            }
            else
            {
                if(count < 10)
                {
                    txtbox_MatchID.Text = year + "00" + (count + 1);
                }
                else if(count < 100)
                {
                    txtbox_MatchID.Text = year + "0" + (count + 1);
                }
                else
                {
                    txtbox_MatchID.Text = $"{year}" + $"{count + 1}";
                }
            }
        }

        private void cbox_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(fin == true)
            {
                if (cbox_TeamHome.Text == cbox_TeamAway.Text)
                {
                    MessageBox.Show("Team Home and Team Away Should Be Different");
                }
                else if (cbox_TeamHome.SelectedItem != null && cbox_TeamAway.SelectedItem != null)
                {
                    dtSelectedTeam.Clear();
                    dtSelectedTeam.Rows.Add(cbox_TeamHome.SelectedValue.ToString(), cbox_TeamHome.Text);
                    dtSelectedTeam.Rows.Add(cbox_TeamAway.SelectedValue.ToString(), cbox_TeamAway.Text);
                    cbox_AddTeam.DataSource = dtSelectedTeam;
                    cbox_AddTeam.DisplayMember = "team_name";
                    cbox_AddTeam.ValueMember = "team_id";
                }
            }
        }

        private void cbox_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(fin == true)
            {
                if (cbox_TeamHome.Text == cbox_TeamAway.Text)
                {
                    MessageBox.Show("Team Home and Team Away Should Be Different");
                }
                else if (cbox_TeamHome.SelectedItem != null && cbox_TeamAway.SelectedItem != null)
                {
                    dtSelectedTeam.Clear();
                    dtSelectedTeam.Rows.Add(cbox_TeamHome.SelectedValue.ToString(), cbox_TeamHome.Text);
                    dtSelectedTeam.Rows.Add(cbox_TeamAway.SelectedValue.ToString(), cbox_TeamAway.Text);
                    cbox_AddTeam.DataSource = dtSelectedTeam;
                    cbox_AddTeam.DisplayMember = "team_name";
                    cbox_AddTeam.ValueMember = "team_id";
                }
            }
        }
    }
}
